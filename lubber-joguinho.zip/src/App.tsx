
import { useState } from "react";

export default function Joguinho() {
  const [escolha, setEscolha] = useState<number | null>(null);
  const [ganhou, setGanhou] = useState<boolean | null>(null);

  const premioIndex = Math.floor(Math.random() * 3);

  const escolher = (index: number) => {
    if (escolha !== null) return;
    setEscolha(index);
    setGanhou(index === premioIndex);
  };

  const mensagens = {
    vitoria: "🎉 Você ganhou R$ 50! Seu prêmio será creditado na sua carteira em até 24h.",
    derrota: "😢 Que pena, não foi desta vez. Continue usando a Lubber Driver e tente novamente!",
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white gap-6 p-4">
      <h1 className="text-2xl font-bold text-center">Escolha uma caixa e boa sorte!</h1>

      <div className="flex gap-4">
        {[0, 1, 2].map((i) => (
          <button
            key={i}
            onClick={() => escolher(i)}
            disabled={escolha !== null}
            className={\`w-24 h-24 rounded-2xl text-white font-bold text-xl shadow-md
              \${escolha === i ? "bg-blue-500" : "bg-gray-700"}
              \${escolha !== null && escolha !== i ? "opacity-40" : ""}
            \`}
          >
            {escolha === i ? (ganhou ? "💰" : "❌") : "?"}
          </button>
        ))}
      </div>

      {ganhou !== null && (
        <p className="text-lg text-center max-w-sm">
          {ganhou ? mensagens.vitoria : mensagens.derrota}
        </p>
      )}
    </div>
  );
}
